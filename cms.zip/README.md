# This Project is made usingn react.js and firebase
# The goal is to provide a crime management sytem that displays new crimes happening around and also allows the authority users to search and add criminals to the database.
# The diferent technologies used are tailwind css, react-icons.